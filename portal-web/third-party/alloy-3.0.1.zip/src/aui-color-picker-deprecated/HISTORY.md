aui-color-picker-deprecated
========
